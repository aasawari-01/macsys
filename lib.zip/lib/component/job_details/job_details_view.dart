import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:macsys/component/job_details/job_details_controller.dart';
import 'package:remixicon/remixicon.dart';

import '../../services/remote_services.dart';
import '../../util/ApiClient.dart';
import '../../util/CustomLoading.dart';
import '../../util/SizeConfig.dart';
import '../custom_widget/colorsC.dart';
import '../custom_widget/cust_text.dart';
import '../custom_widget/cust_text_start.dart';
import '../daily_job_sheet/daily_job_shee_view.dart';
import '../daily_job_sheet/daily_job_sheet_controller.dart';

class JobsDetilasView extends StatelessWidget {
  var jobID;
  DateTime dateTime = DateTime.now();

  JobsDetilasView(jobID) {
    this.jobID = jobID;
  }

  final FocusNode searchReadingFocus = FocusNode();
  var jobsDetailsController = Get.put(JobsDetailsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: colorPrimaryDark,
        leading: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Remix.arrow_left_line,
              size: 6 * SizeConfig.imageSizeMultiplier,
              color: Colors.white,
            )),
        title: CustText(
            name: "Job Details",
            size: 2.2,
            colors: Colors.white,
            fontWeightName: FontWeight.w600),
      ),
      body: Stack(
        children: [
          Container(
            height: 100 * SizeConfig.heightMultiplier,
            width: 100 * SizeConfig.widthMultiplier,
            child: Image.asset(
              'assets/icons/ic_home.png',
              fit: BoxFit.fitHeight,
            ),
          ),
          Container(
            height: 100 * SizeConfig.heightMultiplier,
            width: 100 * SizeConfig.widthMultiplier,
            color: Colors.white.withOpacity(0.9),
            child: GetBuilder<JobsDetailsController>(
              init: JobsDetailsController(),
              builder: (controller) => jobsDetailsController.status == true
                  ? SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.all(2 * SizeConfig.widthMultiplier),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: 90 * SizeConfig.widthMultiplier,
                                    child: CustTextStart(
                                        name:
                                            "Before start work read/ understand job details carefully",
                                        size: 1.8,
                                        colors: colorPrimary,
                                        fontWeightName: FontWeight.w600)),
                              ],
                            ),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Job Date",
                                "${ApiClient.convertDate(jobsDetailsController.jobsList.fromDate.toString())}"),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Customer Name",
                                "${jobsDetailsController.jobsList.supervisorDetail.firstName} ${jobsDetailsController.jobsList.supervisorDetail.lastName}"),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            // showDetails("Supervisor's Name","${jobsDetailsController.jobDetailsResult[0].supervisorName}"),
                            showDetails("Supervisor's Name",
                                "${jobsDetailsController.jobsList.customerName} "),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Supervisor's Number",
                                "${jobsDetailsController.jobsList.supervisorDetail.personalMobile}"),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Supervisor's Email",
                                "${jobsDetailsController.jobsList.supervisorDetail.personalEmail}"),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Site Address",
                                "${jobsDetailsController.jobsList.siteAddress}"),

                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Job Type",
                                "${jobsDetailsController.jobsList.type}"),

                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Notes",
                                "${jobsDetailsController.jobsList.notes}"),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            showDetails("Created Date",
                                "${ApiClient.convertDate(jobsDetailsController.jobsList.createdAt.toString())}"),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Center(
                                child: TextFormField(
                                  onChanged: (term) {
                                    jobsDetailsController.filterList(term);
                                  },

                                  textAlign: TextAlign.start,
                                  style: GoogleFonts.openSans(
                                    textStyle: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 1.6 * SizeConfig.textMultiplier,
                                    ),
                                  ),
                                  // controller: DJSController.JobDescriptionController,
                                  cursorColor: Colors.black,
                                  textInputAction: TextInputAction.next,
                                  focusNode: searchReadingFocus,
                                  onFieldSubmitted: (term) {
                                    _fieldFocusChange(
                                        context, searchReadingFocus);
                                  },
                                  decoration: InputDecoration(
                                    prefixIcon: Icon(
                                      Icons.search,
                                      color: Colors.black,
                                      size: 6 * SizeConfig.imageSizeMultiplier,
                                    ),
                                    // labelText: "Enter Email",
                                    // isDense: true,
                                    contentPadding: EdgeInsets.only(
                                      top: 2 * SizeConfig.widthMultiplier,
                                      left: 2 * SizeConfig.widthMultiplier,
                                      right: 2 * SizeConfig.widthMultiplier,
                                    ),
                                    constraints: BoxConstraints.tightFor(
                                        height:
                                            5 * SizeConfig.heightMultiplier),
                                    fillColor: const Color(0xFF689fef),
                                    /*contentPadding: new EdgeInsets.symmetric(
                                              vertical:
                                              2 * SizeConfig.widthMultiplier,
                                              horizontal:
                                              2 * SizeConfig.widthMultiplier),*/
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Colors.black,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                        // width: 2.0,
                                      ),
                                    ),
                                    hintText: "Search Vehicle",
                                    labelStyle: GoogleFonts.openSans(
                                        textStyle: TextStyle(
                                      color: const Color(0xFF888888),
                                      fontSize: 1.6 * SizeConfig.textMultiplier,
                                      fontWeight: FontWeight.w400,
                                    )),
                                    hintStyle: GoogleFonts.openSans(
                                        textStyle: TextStyle(
                                      color: const Color(0xFF888888),
                                      fontSize: 1.6 * SizeConfig.textMultiplier,
                                      fontWeight: FontWeight.w400,
                                    )),
                                  ),
                                ),
                              ),
                            ),
                            ListView.builder(
                              padding: EdgeInsets.zero,
                              //physics: ,
                              primary: false,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount:
                                  jobsDetailsController.filteredAssignVehicle.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Padding(
                                  padding: EdgeInsets.only(
                                      top: 0.5 * SizeConfig.heightMultiplier,
                                      bottom:
                                          0.5 * SizeConfig.heightMultiplier),
                                  child: GestureDetector(
                                    onTap: () {
                                      // jobsDetailsController.filteredAssignVehicle[0].truckPlantUnitNo
                                      if (jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .dailyJobSheet ==
                                              0 &&
                                          jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .isdraft ==
                                              0) {
                                        var DJSController =
                                            Get.put(DailyJobSheetController());
                                        DJSController.cleanData();
                                        Get.to(DailyJobSheetView(
                                            jobsDetailsController
                                                .filteredAssignVehicle[index],
                                            dateTime,
                                            jobsDetailsController
                                                .filteredAssignVehicle[index].jobId,
                                            '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'
                                            ''));
                                      }
                                      if (jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .dailyJobSheet ==
                                              1 &&
                                          jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .isdraft ==
                                              1) {
                                        //Todo here///
                                        var DJSController =
                                            Get.put(DailyJobSheetController());
                                        DJSController.cleanData();
                                        DJSController.getDraftJobSheet(
                                            jobsDetailsController
                                                .filteredAssignVehicle[index]
                                                .vehicleId);
                                        Get.to(DailyJobSheetView(
                                            jobsDetailsController
                                                .filteredAssignVehicle[index],
                                            /*jobsDetailsController
                                                .jobDetailsResult[0].dateTime,*/
                                            dateTime,
                                            jobsDetailsController
                                                .filteredAssignVehicle[index].jobId,
                                            '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'
                                            ''));
                                      }
                                      if (jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .dailyJobSheet ==
                                              1 &&
                                          jobsDetailsController
                                                  .filteredAssignVehicle[index]
                                                  .isdraft ==
                                              0) {
                                        //Todo here///
                                        var DJSController =
                                            Get.put(DailyJobSheetController());
                                        DJSController.cleanData();
                                        DJSController.getDraftJobSheet(
                                            jobsDetailsController
                                                .filteredAssignVehicle[index]
                                                .vehicleId);
                                        Get.to(DailyJobSheetView(
                                            jobsDetailsController
                                                .filteredAssignVehicle[index],
                                            /*jobsDetailsController
                                                .jobDetailsResult[0].dateTime,*/
                                            dateTime,
                                            jobsDetailsController
                                                .filteredAssignVehicle[index].jobId,
                                            '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'
                                            ''));
                                      }
                                    },
                                    child: Container(
                                      width: 100 * SizeConfig.widthMultiplier,
                                      color: Colors.white,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Container(
                                                height: 10 *
                                                    SizeConfig.heightMultiplier,
                                                width: 15 *
                                                    SizeConfig.widthMultiplier,
                                                child: jobsDetailsController
                                                            .filteredAssignVehicle[
                                                                index]
                                                            .vehicleImage ==
                                                        null
                                                    ? Image.network(
                                                        "https://t4.ftcdn.net/jpg/02/51/95/53/240_F_251955356_FAQH0U1y1TZw3ZcdPGybwUkH90a3VAhb.jpg")
                                                    : Image.network(
                                                        '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'),
                                              ),
                                              SizedBox(
                                                width: 2 *
                                                    SizeConfig.widthMultiplier,
                                              ),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CustTextStart(
                                                      name:
                                                          jobsDetailsController
                                                              .filteredAssignVehicle[
                                                                  index]
                                                              .vehicleNo,
                                                      size: 2,
                                                      colors: colorPrimaryDark,
                                                      fontWeightName:
                                                          FontWeight.w600),
                                                  SizedBox(
                                                      height: 0.5 *
                                                          SizeConfig
                                                              .heightMultiplier),
                                                  CustTextStart(
                                                      name: jobsDetailsController
                                                              .crewNamesList
                                                              .isEmpty
                                                          ? "No Crew Assign"
                                                          : jobsDetailsController
                                                                  .crewNamesList[
                                                              index],
                                                      // "${jobsDetailsController.filteredAssignVehicle[index].crewVehicleAllocation[0].firstName} ${jobsDetailsController.filteredAssignVehicle[index].crewVehicleAllocation[0].lastName}",
                                                      // "${jobsDetailsController.filteredAssignVehicle[index].firstName} ${jobsDetailsController.filteredAssignVehicle[index].lastName}",
                                                      size: 1.8,
                                                      colors: Colors.black87,
                                                      fontWeightName:
                                                          FontWeight.w400),
                                                ],
                                              )
                                            ],
                                          ),
                                          Row(
                                            children: [
                                              jobsDetailsController
                                                              .filteredAssignVehicle[
                                                                  index]
                                                              .isdraft ==
                                                          1 &&
                                                      jobsDetailsController
                                                              .filteredAssignVehicle[
                                                                  index]
                                                              .dailyJobSheet ==
                                                          1
                                                  ? Row(
                                                      children: [
                                                        jobsDetailsController.filteredAssignVehicle[index].vehStatus == "In Working"
                                                            ? Container()
                                                            : Container(
                                                                decoration: BoxDecoration(
                                                                    border: Border.all(
                                                                        width:
                                                                            2,
                                                                        style: BorderStyle
                                                                            .solid,
                                                                        color:
                                                                            colorPrimary),
                                                                    borderRadius:
                                                                        BorderRadius.all(Radius.circular(
                                                                            5))),
                                                                padding: EdgeInsets.symmetric(
                                                                    horizontal:
                                                                        SizeConfig.widthMultiplier *
                                                                            1.5,
                                                                    vertical:
                                                                        SizeConfig.heightMultiplier *
                                                                            0.2),
                                                                child: jobsDetailsController.filteredAssignVehicle[index].vehStatus == "Idle"
                                                                    ? CustTextStart(
                                                                        name: "Idle",
                                                                        size: 1.4,
                                                                        colors: colorPrimary,
                                                                        fontWeightName: FontWeight.w500)
                                                                    : CustTextStart(name: "Maintenance", size: 1.2, colors: colorPrimary, fontWeightName: FontWeight.w500)),
                                                        SizedBox(
                                                          width: 2 *
                                                              SizeConfig
                                                                  .widthMultiplier,
                                                        ),
                                                        Icon(Remix.draft_fill,
                                                            size: 7 *
                                                                SizeConfig
                                                                    .imageSizeMultiplier,
                                                            color:
                                                                colorPrimaryDark),
                                                      ],
                                                    )
                                                  : Container(),
                                              SizedBox(
                                                width: 1 *
                                                    SizeConfig.widthMultiplier,
                                              ),
                                              jobsDetailsController
                                                              .filteredAssignVehicle[
                                                                  index]
                                                              .dailyJobSheet ==
                                                          1 &&
                                                      jobsDetailsController
                                                              .filteredAssignVehicle[
                                                                  index]
                                                              .isdraft ==
                                                          0
                                                  ? Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            jobsDetailsController.filteredAssignVehicle[index].vehStatus ==
                                                                    "In Working"
                                                                ? Container()
                                                                : Container(
                                                                    decoration: BoxDecoration(
                                                                        border: Border.all(
                                                                            width:
                                                                                2,
                                                                            style: BorderStyle
                                                                                .solid,
                                                                            color:
                                                                                colorPrimary),
                                                                        borderRadius: BorderRadius.all(Radius.circular(
                                                                            5))),
                                                                    padding: EdgeInsets.symmetric(
                                                                        horizontal: SizeConfig.widthMultiplier *
                                                                            1.5,
                                                                        vertical: SizeConfig.heightMultiplier *
                                                                            0.2),
                                                                    child: jobsDetailsController.filteredAssignVehicle[index].vehStatus ==
                                                                            "Idle"
                                                                        ? CustTextStart(
                                                                            name: "Idle",
                                                                            size: 1.4,
                                                                            colors: colorPrimary,
                                                                            fontWeightName: FontWeight.w500)
                                                                        : CustTextStart(name: "Maintenance", size: 1.2, colors: colorPrimary, fontWeightName: FontWeight.w500)),
                                                            SizedBox(
                                                              width: 2 *
                                                                  SizeConfig
                                                                      .widthMultiplier,
                                                            ),
                                                            Icon(
                                                                Remix
                                                                    .checkbox_circle_fill,
                                                                size: 7 *
                                                                    SizeConfig
                                                                        .imageSizeMultiplier,
                                                                color:
                                                                    colorPrimaryDark),
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          height: SizeConfig
                                                                  .heightMultiplier *
                                                              0.5,
                                                        ),
                                                        Row(
                                                          children: [
                                                            GestureDetector(
                                                              onTap: () {
                                                                var DJSController =
                                                                    Get.put(
                                                                        DailyJobSheetController());
                                                                DJSController
                                                                    .cleanData();
                                                                Get.to(
                                                                    DailyJobSheetView(
                                                                        jobsDetailsController.filteredAssignVehicle[
                                                                            index],
                                                                        dateTime,
                                                                        jobsDetailsController
                                                                            .filteredAssignVehicle[index]
                                                                            .jobId,
                                                                        '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'
                                                                        ''));
                                                                Get.to(DailyJobSheetView(
                                                                    jobsDetailsController.filteredAssignVehicle[index],
                                                                    dateTime,
                                                                    jobID,
                                                                    '${RemoteServices.baseUrl}${jobsDetailsController.filteredAssignVehicle[index].vehicleImage}'
                                                                    ''));
                                                                DJSController.getDraftJobSheet(
                                                                    jobsDetailsController
                                                                        .filteredAssignVehicle[
                                                                            index]
                                                                        .vehicleId);
                                                              },
                                                              child: Container(
                                                                  decoration: BoxDecoration(
                                                                      border: Border.all(
                                                                          width:
                                                                              2,
                                                                          style: BorderStyle
                                                                              .solid,
                                                                          color:
                                                                              colorPrimary),
                                                                      borderRadius:
                                                                          BorderRadius.all(Radius.circular(
                                                                              5))),
                                                                  padding: EdgeInsets.symmetric(
                                                                      horizontal:
                                                                          SizeConfig.widthMultiplier *
                                                                              1.5,
                                                                      vertical:
                                                                          SizeConfig.heightMultiplier *
                                                                              0.5),
                                                                  child: CustTextStart(
                                                                      name: "Fill Again",
                                                                      size: 1.4,
                                                                      colors: colorPrimary,
                                                                      fontWeightName: FontWeight.w500)),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    )

                                                  // Icon(Remix.arrow_right_s_line,size: 7 * SizeConfig.imageSizeMultiplier,color: colorPrimaryDark)
                                                  :
                                                  // Icon(Remix.checkbox_circle_fill,size: 7 * SizeConfig.imageSizeMultiplier,color: colorPrimaryDark),

                                                  Icon(Remix.arrow_right_s_line,
                                                      size: 7 *
                                                          SizeConfig
                                                              .imageSizeMultiplier,
                                                      color: colorPrimaryDark),
                                              SizedBox(
                                                width: 4 *
                                                    SizeConfig.widthMultiplier,
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            )
                          ],
                        ),
                      ),
                    )
                  : Container(child: CustomLoading()),
            ),
          ),
        ],
      ),
    );
  }

  showDetails(title, details) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
            width: 42 * SizeConfig.widthMultiplier,
            child: CustTextStart(
                name: title,
                size: 1.6,
                colors: Colors.black87,
                fontWeightName: FontWeight.w600)),
        CustText(
            name: ":  ",
            size: 1.8,
            colors: Colors.black87,
            fontWeightName: FontWeight.w400),
        Container(
            width: 48 * SizeConfig.widthMultiplier,
            child: CustTextStart(
                name: details,
                size: 1.8,
                colors: Colors.black87,
                fontWeightName: FontWeight.w400)),
      ],
    );
  }

  _fieldFocusChange(BuildContext context, FocusNode currentFocus) {
    currentFocus.unfocus();
  }
}
