import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../services/remote_services.dart';
import '../../util/ApiClient.dart';
import '../login/login_controller.dart';
import 'home_model.dart';


class HomeController extends GetxController{
  bool fuelManager=false;
  bool superVisorsAdmin=false;
  var allocated = 0,  ongoing = 0;
  var status,msg;
  String version="";
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getVersion();
    cleanData();
    // ApiClient.box.write('token',"61e03c65981c20eb3796e4ca29cd3df3d71fabd4a5");
  }

  getVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    version = packageInfo.version;
    print("version::${version}");
    ApiClient.box.write("version", version);
    update();
  }
  Future getJobs() async{
    try {
      var getDetails = await RemoteServices.fetchGetData('api/v1/dashboard');
      print("${getDetails.body}");
      if(getDetails.statusCode == 200){
        var apiDetails = homeModelFromJson(getDetails.body);
        allocated = apiDetails.allocated;
        ongoing = apiDetails.ongoing;
       print("JOBS::${apiDetails}");
       if(ApiClient.box.read('skills')=="Diesel Manager"){
         print("Here is the Diesel Manager");
         fuelManager= true;
         superVisorsAdmin=false;
       }else if(ApiClient.box.read('skills')=="Supervisors Admin"){
         fuelManager=false;
         superVisorsAdmin=true;
       }
       else{
         fuelManager= false;
         superVisorsAdmin=false;
       }
      }else{
         // checkUpdate();
        print("Exception");
      }
    }  catch (e) {
      print("catch  == $e");
      //   checkUpdate();
    }

    update();
  }
  /*Future getJobs() async{
    try {
      Map map ={
        "user_id": ApiClient.box.read('userId')
      };
      print("map  == $map");
      var getDetails = await RemoteServices.fetchGetData('api/v1/jobs');
      print("${getDetails.body}");
      // if(getDetails.statusCode == 200){
      //   var apiDetails = homeModelFromJson(getDetails.body);
      //   if(apiDetails.flag == 1){
      //     status = apiDetails.flag;
      //     msg = apiDetails.msg;
      //     allocated = apiDetails.allocated!;
      //     ongoing = apiDetails.ongoing!;
      //     print("Details${apiDetails.msg!}");
      //     print("Details${apiDetails.allocated!}");
      //     print("Details${apiDetails.ongoing!}");
      //   }
      // }else{
      //   //  checkUpdate();
      // }
    }  catch (e) {
      print("catch  == $e");
      //   checkUpdate();
    }

    update();
  }*/

 void logout() {
    print("Before ${ApiClient.box.read("login")}");
    ApiClient.box.write('token',"");
    ApiClient.box.write('login',false);
    ApiClient.box.write('userId',"");
    ApiClient.box.write('superName',"");
    ApiClient.box.write('superEmail',"");
    ApiClient.box.write('superMobile',"");
    ApiClient.box.write('crewEmail',"");
    ApiClient.box.write('crewMobile',"");
    ApiClient.box.write('image',"");
    ApiClient.box.write('userId',"");
    ApiClient.box.write('skills',"");
    ApiClient.box.write('status',"0");
    ApiClient.box.write('supervisorsAdmin',"0");
    // ApiClient.box.erase();
    print("After :${ApiClient.box.read("login")}");

    print("VALUESS::${ApiClient.box.getValues()}");
    print("BEFORE ${ApiClient.box.read('login')}");
    Get.deleteAll();
    update();
    print("${ApiClient.box.read('login')}");
    loginStatus= false;

  }

  double TotalPurchaseBalance = 0.0;
  double TotalUsedFuel = 0.0;
  double TotalRemainingFuel = 0.0;

  updatePurchaseBalance(PFuel) {
    TotalPurchaseBalance = PFuel;
    update();
  }
  updateUsedBalance(UFuel) {
    TotalUsedFuel = UFuel;
    update();
  }
  updateRemainingFuel(RFuel) {
    TotalRemainingFuel = RFuel;
    update();
  }
  cleanData(){
    TotalUsedFuel=0.0;
    TotalPurchaseBalance=0.0;
    TotalRemainingFuel=0.0;
    update();
  }


}
