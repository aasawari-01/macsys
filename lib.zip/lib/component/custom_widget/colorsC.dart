import 'package:flutter/animation.dart';

const colorPrimary = Color(0xFF004981);
const colorPrimaryDark = Color(0xFF003b68);


