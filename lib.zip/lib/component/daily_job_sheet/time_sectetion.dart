import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../util/SizeConfig.dart';
import '../../util/custom_dialog.dart';
import '../custom_widget/colorsC.dart';
import '../custom_widget/cust_text.dart';
import 'daily_job_sheet_controller.dart';

class timeSectetion extends StatelessWidget {
  var time, isstartTime, index;

  timeSectetion({
    required this.time,
    required this.isstartTime,
    required this.index,
  });

  var DJSController = Get.put(DailyJobSheetController());

  bool dateTimeChanged = false;

  @override
  Widget build(BuildContext context) {


    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
      elevation: 0.0,
      backgroundColor: Colors.transparent,
      child: dialogContent(context),
    );
  }

  Widget dialogContent(BuildContext context) {
    return GetBuilder<DailyJobSheetController>(
      init: DailyJobSheetController(),
      builder: (controller) => Container(
        color: colorPrimary,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 1 * SizeConfig.heightMultiplier,
            ),
            CustText(
                name: "TODAY'S WORKING HOURS",
                size: 1.8,
                colors: Colors.white,
                fontWeightName: FontWeight.w600),
            SizedBox(
              height: 1 * SizeConfig.heightMultiplier,
            ),
            Container(
              height: 25 * SizeConfig.heightMultiplier,
              child: CupertinoTheme(
                data: CupertinoThemeData(
                  brightness: CupertinoTheme.of(context).brightness,
                  primaryColor: Colors.white,
                  primaryContrastingColor: Colors.white,
                  textTheme: CupertinoTextThemeData(
                    dateTimePickerTextStyle: GoogleFonts.notoSans(
                        textStyle: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.normal,
                      fontSize: 2 * SizeConfig.textMultiplier,
                    )),
                  ),
                ),
                child: CupertinoDatePicker(
                        mode: CupertinoDatePickerMode.time,
                        minimumDate: time,
                        // minimumDate: DateTime.now().subtract(Duration(days: 1)),
                        initialDateTime: DateTime.now(),
                        // initialDateTime:  DJSController.jobType == "day"?DateTime.now():time,
                        // minimumDate:DJSController.jobType == "day"?time :getYesterday(),
                        backgroundColor: colorPrimary,
                        maximumDate: DateTime.now(),
                        // maximumDate: DateTime.now().subtract(Duration(days: 1)),
                        onDateTimeChanged: (DateTime newDateTime) {
                          DJSController.updateTime(newDateTime, isstartTime);
                          dateTimeChanged = true;

                          // meetUpController.updateTemp(newDateTime);
                        },
                      )

              ),
            ),
            SizedBox(
              height: 2 * SizeConfig.heightMultiplier,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                      height: 5 * SizeConfig.heightMultiplier,
                      width: 35 * SizeConfig.widthMultiplier,
                      decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          borderRadius: BorderRadius.all(
                              Radius.circular(2 * SizeConfig.widthMultiplier)),
                          border: Border.all(
                              width: 0.0 * SizeConfig.widthMultiplier,
                              color: Colors.grey,
                              strokeAlign: BorderSide.strokeAlignCenter)),
                      child: Center(
                          child: CustText(
                              name: "Cancel",
                              size: 1.8,
                              colors: Colors.black,
                              fontWeightName: FontWeight.w600))),
                ),
                SizedBox(width: 2 * SizeConfig.widthMultiplier),
                GestureDetector(
                  onTap: () {
                    if (!dateTimeChanged) {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) =>
                              CustomDialog("Please Change Time "));
                      print("$time");

                      // DJSController.updateTime(selectedTime, isstartTime);
                      // DJSController.submitTime(index, isstartTime);
                    } else {
                      DJSController.submitTime(index, isstartTime);
                      DJSController.tt();
                      Navigator.pop(context);
                    }
                  },
                  child: Container(
                      height: 5 * SizeConfig.heightMultiplier,
                      width: 35 * SizeConfig.widthMultiplier,
                      decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          borderRadius: BorderRadius.all(
                              Radius.circular(2 * SizeConfig.widthMultiplier)),
                          border: Border.all(
                              width: 0.0 * SizeConfig.widthMultiplier,
                              color: Colors.grey,
                              strokeAlign: BorderSide.strokeAlignCenter)),
                      child: Center(
                          child: CustText(
                              name: "Submit",
                              size: 1.8,
                              colors: Colors.black,
                              fontWeightName: FontWeight.w600))),
                ),
              ],
            ),
            SizedBox(
              height: 1 * SizeConfig.heightMultiplier,
            ),
          ],
        ),
      ),
    );
  }
}
