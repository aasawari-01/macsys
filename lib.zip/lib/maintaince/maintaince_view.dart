import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:macsys/component/job_details/job_details_controller.dart';
import 'package:macsys/util/fuel_selection_dialog.dart';
import 'package:remixicon/remixicon.dart';
import '../../services/remote_services.dart';
import '../../util/ApiClient.dart';
import '../../util/SizeConfig.dart';
import '../../util/custom_dialog.dart';
import '../component/custom_widget/check_internet.dart';
import '../component/custom_widget/colorsC.dart';
import '../component/custom_widget/cust_text.dart';
import '../component/custom_widget/cust_text_start.dart';
import '../component/custom_widget/custom_loading_popup.dart';
import '../component/custom_widget/selectionDialog.dart';
import 'maintaince_controller.dart';

class MaintenanceView extends StatelessWidget {

  final String VehicleName;
  final int vehicleID;
var details;
  MaintenanceView({required this.VehicleName,required this.vehicleID,this.details});

  var maintenanceController = Get.put(MaintenanceController());
  final FocusNode descFocus = FocusNode();
  final FocusNode noteFocus = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: colorPrimaryDark,
        leading: GestureDetector(
          onTap: () {
            maintenanceController.cleanData();
            Navigator.pop(context);
          },
          child: Icon(
            Remix.arrow_left_line,
            size: 6 * SizeConfig.imageSizeMultiplier,
            color: Colors.white,
          ),
        ),
        title: CustText(
            name: "Add Vehicle Maintenance",
            size: 2.2,
            colors: Colors.white,
            fontWeightName: FontWeight.w600),
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            GetBuilder<MaintenanceController>(
                init: MaintenanceController(),
                builder: (controller) => maintenanceController.status
                    ? Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: 1 * SizeConfig.heightMultiplier,
                      horizontal: 3 * SizeConfig.widthMultiplier),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 5.5 * SizeConfig.heightMultiplier,
                        width: 100 * SizeConfig.widthMultiplier,
                        color: colorPrimary,
                        child: Center(
                          child: CustText(
                              name: "Vehicle Details",
                              size: 1.8,
                              colors: Colors.white,
                              fontWeightName: FontWeight.w600),
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier * 1,
                      ),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustText(
                                  name: "Vehicle Name",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              CustText(
                                  name: "    :    ",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              Container(
                                height: 5.5 * SizeConfig.heightMultiplier,
                                width: 50 * SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(
                                          1 * SizeConfig.widthMultiplier)),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius:
                                      2 * SizeConfig.widthMultiplier,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Container(
                                    child: CustText(
                                        name:"${this.VehicleName}",
                                        size: 1.8,
                                        colors: Colors.black,
                                        fontWeightName: FontWeight.w700),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: SizeConfig.heightMultiplier * 1),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustText(
                                  name: "Maintaince Type",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              CustText(
                                  name: "    :      ",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              Container(
                                height: 5.5 * SizeConfig.heightMultiplier,
                                width: 50 * SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(
                                          1 * SizeConfig.widthMultiplier)),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius:
                                      2 * SizeConfig.widthMultiplier,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Container(
                                    child: GestureDetector(
                                      onTap: () {
                                        showDialog(
                                            barrierDismissible: true,
                                            context: context,
                                            builder: (BuildContext context) =>
                                                SelectionDialog(
                                                  list:
                                                  maintenanceController.maintenanceType,
                                                  onSelected: (type,index) {
                                                  /*  maintenanceController
                                                        .locationId =
                                                        locationid;*/
                                                  print("Index $index, $type");
                                                    maintenanceController
                                                        .updateType(
                                                        type);
                                                    // maintenanceController.updateFuelBalance(index,true);

                                                  },
                                                  flag: 0,
                                                ));
                                      },
                                      child: CustText(
                                          name: maintenanceController.selectedType,
                                          size: 1.6,
                                          colors:
                                          maintenanceController.selectedType ==
                                              "Select Type"
                                              ? Colors.grey
                                              : Colors.black,
                                          fontWeightName: FontWeight.w600),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: SizeConfig.heightMultiplier * 1),
                        /*  Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustText(
                                  name: "Job Assign To",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              CustText(
                                  name: "    :      ",
                                  size: 1.8,
                                  colors: Colors.black,
                                  fontWeightName: FontWeight.w600),
                              Container(
                                height: 5.5 * SizeConfig.heightMultiplier,
                                width: 50 * SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(
                                          1 * SizeConfig.widthMultiplier)),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius:
                                      2 * SizeConfig.widthMultiplier,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Container(
                                    child: GestureDetector(
                                      onTap: () {
                                        showDialog(
                                            barrierDismissible: true,
                                            context: context,
                                            builder: (BuildContext context) =>
                                                SelectionDialog(
                                                  list:
                                                  maintenanceController.location,
                                                  onSelected: (person,index) {
                                                    *//*maintenanceController
                                                        .locationId =
                                                        locationid;*//*
                                                    *//*print(
                                                        "selected : $locationid  Name::$name");*//*
                                                  *//*  maintenanceController
                                                        .updatePersonName(
                                                        name);
                                                    maintenanceController.updateFuelBalance(index,true);*//*

                                                  },
                                                  flag: 1,
                                                ));
                                      },
                                      child: CustText(
                                          name:
                                          maintenanceController.selectedAssignJob,
                                          size: 1.6,
                                          colors: maintenanceController
                                              .selectedAssignJob == "Select Person"
                                              ? Colors.grey
                                              : Colors.black,
                                          fontWeightName: FontWeight.w600),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: SizeConfig.heightMultiplier * 1),*/
                        ],
                      ),

                     /* Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustText(
                              name: "Maintenance\nSupervisor",
                              size: 1.8,
                              colors: Colors.black,
                              fontWeightName: FontWeight.w600),
                          CustText(
                              name: ":",
                              size: 1.8,
                              colors: Colors.black,
                              fontWeightName: FontWeight.w600),
                          Container(
                            height: 5.5 * SizeConfig.heightMultiplier,
                            width: 50 * SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(
                                  Radius.circular(
                                      1 * SizeConfig.widthMultiplier)),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius:
                                  2 * SizeConfig.widthMultiplier,
                                ),
                              ],
                            ),

                            child: Center(
                              child: Container(
                                child: GestureDetector(
                                  onTap: () {
                                    showDialog(
                                        barrierDismissible: true,
                                        context: context,
                                        builder: (BuildContext context) =>
                                            SelectionDialog(
                                              list: maintenanceController
                                                  .petroleum,
                                              onSelected:
                                                  (update,index) {
                                                *//*maintenanceController.companyId =
                                                    id;*//*
                                                print(
                                                    "selected :$index");
                                               *//* maintenanceController
                                                    .updateType(name);
                                                maintenanceController
                                                    .updateRate(index);*//*
                                              },
                                              flag: 2,
                                            ));
                                  },
                                  child: CustText(
                                      name: maintenanceController.selectedSupervisor,
                                      size: 1.6,
                                      colors:
                                      maintenanceController.selectedSupervisor ==
                                          "Select Supervisor"
                                          ? Colors.grey
                                          : Colors.black,
                                      fontWeightName: FontWeight.w600),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),*/
                      SizedBox(height: SizeConfig.heightMultiplier * 2),
                      Container(
                        width: 100*SizeConfig.widthMultiplier,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustTextStart(
                                name: "Description",
                                size: 1.8,
                                colors: Colors.black,
                                fontWeightName: FontWeight.w600),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            Container(
                              height: 10 * SizeConfig.heightMultiplier,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.all(Radius.circular(
                                    2 * SizeConfig.widthMultiplier)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius:
                                    2 * SizeConfig.widthMultiplier,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: TextFormField(
                                  textAlign: TextAlign.start,
                                  style: GoogleFonts.openSans(
                                      textStyle: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize:
                                        1.6 * SizeConfig.textMultiplier,
                                      )),
                                  controller:
                                  maintenanceController.descController,
                                  cursorColor: Colors.black,
                                  textInputAction: TextInputAction.next,
                                  focusNode: descFocus,
                                  onChanged: (value) {
                                    print("object $value");
                                  },

                                  onFieldSubmitted: (value) {
                                    descFocus.unfocus();
                                    // maintenanceController.calculateRate(value);
                                    //  _calculator();
                                  },
                                  maxLines: 7,
                                  decoration: InputDecoration(
                                    // labelText: "Enter Email",
                                    // isDense: true,
                                    counterText: "",
                                    contentPadding: EdgeInsets.only(
                                      top: 2 * SizeConfig.widthMultiplier,
                                      left: 2 * SizeConfig.widthMultiplier,
                                      right: 2 * SizeConfig.widthMultiplier,
                                    ),
                                    constraints: BoxConstraints.tightFor(
                                        height: 10 * SizeConfig.heightMultiplier),
                                    fillColor: const Color(0xFF689fef),
                                    /*contentPadding: new EdgeInsets.symmetric(
                                                      vertical:
                                                      2 * SizeConfig.widthMultiplier,
                                                      horizontal:
                                                      2 * SizeConfig.widthMultiplier),*/
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                        // width: 2.0,
                                      ),
                                    ),
                                    hintText: "Enter Description Here",
                                    hintStyle: GoogleFonts.openSans(
                                        textStyle: TextStyle(
                                          color: const Color(0xFF888888),
                                          fontSize:
                                          1.8 * SizeConfig.textMultiplier,
                                          fontWeight: FontWeight.w400,
                                        )),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      maintenanceController.desc != ""
                          ? CustText(
                          name: maintenanceController.desc,
                          size: 1.6,
                          colors: Colors.red,
                          fontWeightName: FontWeight.w400)
                          : Container(),
                      SizedBox(height: SizeConfig.heightMultiplier * 1),
                      Container(
                        width: 100*SizeConfig.widthMultiplier,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustTextStart(
                                name: "Notes",
                                size: 1.8,
                                colors: Colors.black,
                                fontWeightName: FontWeight.w600),
                            SizedBox(height: 1 * SizeConfig.heightMultiplier),
                            Container(
                              height: 7 * SizeConfig.heightMultiplier,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.all(Radius.circular(
                                    2 * SizeConfig.widthMultiplier)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 2 * SizeConfig.widthMultiplier,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: TextFormField(
                                  textAlign: TextAlign.start,
                                  style: GoogleFonts.openSans(
                                      textStyle: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize:
                                        1.6 * SizeConfig.textMultiplier,
                                      )),
                                  controller:
                                  maintenanceController.notesController,
                                  cursorColor: Colors.black,
                                  textInputAction: TextInputAction.next,
                                  focusNode: noteFocus,
                                  onChanged: (value) {
                                    print("object $value");

                                  },
                                  onFieldSubmitted: (value) {
                                    noteFocus.unfocus();
                                    // maintenanceController.calculateRate(value);
                                    //  _calculator();
                                  },
                                  maxLines: 7,
                                  decoration: InputDecoration(
                                    // labelText: "Enter Email",
                                    // isDense: true,
                                    counterText: "",
                                    contentPadding: EdgeInsets.only(
                                      top: 2 * SizeConfig.widthMultiplier,
                                      left: 2 * SizeConfig.widthMultiplier,
                                      right: 2 * SizeConfig.widthMultiplier,
                                    ),
                                    constraints: BoxConstraints.tightFor(
                                        height: 7 * SizeConfig.heightMultiplier),
                                    fillColor: const Color(0xFF689fef),
                                    /*contentPadding: new EdgeInsets.symmetric(
                                                      vertical:
                                                      2 * SizeConfig.widthMultiplier,
                                                      horizontal:
                                                      2 * SizeConfig.widthMultiplier),*/
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          2 * SizeConfig.widthMultiplier),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF689fef),
                                        // width: 2.0,
                                      ),
                                    ),
                                    hintText: "Enter Notes Here",
                                    hintStyle: GoogleFonts.openSans(
                                        textStyle: TextStyle(
                                          color: const Color(0xFF888888),
                                          fontSize:
                                          1.6 * SizeConfig.textMultiplier,
                                          fontWeight: FontWeight.w400,
                                        )),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier * 2,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: () {
                              maintenanceController.cleanData();
                              Get.back();
                            },
                            child: Container(
                                height: 5 * SizeConfig.heightMultiplier,
                                width: 35 * SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.9),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(2 *
                                            SizeConfig.widthMultiplier)),
                                    border: Border.all(
                                        width: 0.18 *
                                            SizeConfig.widthMultiplier,
                                        color: Colors.black,
                                        strokeAlign: BorderSide
                                            .strokeAlignCenter)),
                                child: Center(
                                    child: CustText(
                                        name: "Cancel",
                                        size: 1.8,
                                        colors: Colors.black,
                                        fontWeightName:
                                        FontWeight.w600))),
                          ),
                          GestureDetector(
                            onTap: () async {
                              maintenanceController.checkValidation();
                              if(maintenanceController.selectedType!="Select Type"){
                                print("Here is desc== ${maintenanceController.desc}");
                                  if (maintenanceController.warningText == true) {
                                      FocusScope.of(context)
                                          .requestFocus(new FocusNode());
                                      if (await CheckInternet
                                          .checkInternet()) {
                                        showDialog(
                                            context: context,
                                            builder:
                                                (BuildContext context) =>
                                                CustomLoadingPopup());
                                        await maintenanceController.addFuel(
                                            context,
                                            maintenanceController.companyId,
                                            maintenanceController.purchasePrice,
                                            maintenanceController.litreDouble,
                                            maintenanceController.rateDouble);
                                      } else {
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext
                                            context) =>
                                                CustomDialog(
                                                    "Please check your internet connection"));
                                      }
                                  } else {
                                  }

                              }else{
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) =>
                                        CustomDialog(
                                            "Please select maintenance type !"));
                              }},
                            child: Container(
                                height: 5 * SizeConfig.heightMultiplier,
                                width: 35 * SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.9),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(2 *
                                            SizeConfig.widthMultiplier)),
                                    border: Border.all(
                                        width: 0.18 *
                                            SizeConfig.widthMultiplier,
                                        color: Colors.black,
                                        strokeAlign: BorderSide
                                            .strokeAlignCenter)),
                                child: Center(
                                    child: CustText(
                                        name: "Submit",
                                        size: 1.8,
                                        colors: Colors.black,
                                        fontWeightName:
                                        FontWeight.w600))),
                          ),
                        ],
                      ),
                    ],
                  ),
                )
                    : Container(
                  child: CustomLoadingPopup(),
                )),
          ],
        ),
      ),
    );
  }
}
